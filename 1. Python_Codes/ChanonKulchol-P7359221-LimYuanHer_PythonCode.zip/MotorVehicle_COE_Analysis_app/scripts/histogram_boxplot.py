# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool, 
						  ColumnDataSource, Panel, FactorRange, BasicTickFormatter,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider, 
								  Tabs, CheckboxButtonGroup, 
								  TableColumn, DataTable, Select, Button)
from bokeh.layouts import column, row, WidgetBox

import pymongo
from pymongo import MongoClient

# Make plot with histogram and return tab
def histogram_boxplot_tab(coe_prices_df):

	# Function to make a dataset for histogram based on selected category,
	# start year and end year
	def make_dataset(category, year_start, year_end):

		# Dataframe to hold information
		by_category = pd.DataFrame(columns=['proportion', 'left', 'right', 
										   'f_proportion', 'f_interval',
										   'name', 'color'])

		# Subset to the carrier
		cat_condition = coe_prices_df['vehicle_class'] == category
		year_condition = (coe_prices_df['year'] >= year_start) & (coe_prices_df['year'] <= year_end)
		subset = coe_prices_df[cat_condition & year_condition]

		# Create a histogram with 5 minute bins
		cat_hist, edges = np.histogram(subset['premium'], 
									   bins = 10, 
									   range = [min(subset['premium']), max(subset['premium'])])

		# Divide the counts by the total to get a proportion
		cat_df = pd.DataFrame({'proportion': cat_hist / np.sum(cat_hist), 'left': edges[:-1], 'right': edges[1:] })

		# Format the proportion 
		cat_df['f_proportion'] = ['%0.5f' % proportion for proportion in cat_df['proportion']]

		# Format the interval
		cat_df['f_interval'] = ['%d to %d' % (left, right) for left, right in zip(cat_df['left'], cat_df['right'])]

		# Assign the carrier for labels
		cat_df['name'] = category

		# Add to the overall dataframe
		by_category = by_category.append(cat_df)

		# Overall dataframe
		by_category = by_category.sort_values(['name', 'left'])

		return ColumnDataSource(by_category)

	# Function to make a dataset for boxplot data based on selected category,
	# start year and end year
	def make_bpdata(category, year_start, year_end):
		# Filter for specific vehicle category and period range
		cat_condition = coe_prices_df['vehicle_class'] == category
		year_condition = (coe_prices_df['year'] >= year_start) & (coe_prices_df['year'] <= year_end)
		subset = coe_prices_df[cat_condition & year_condition]

		# Get period range values as list
		cats = subset['year'].unique().tolist()
		cats = [str(i) for i in cats]

		# find the quartiles and IQR for each category
		groups = subset.groupby('year')
		q1 = groups.quantile(q=0.25)
		q2 = groups.quantile(q=0.5)
		q3 = groups.quantile(q=0.75)
		iqr = q3 - q1
		__upper = q3 + 1.5*iqr
		__lower = q1 - 1.5*iqr

		# if no outliers, shrink lengths of stems to be no longer than the minimums or maximums
		qmin = groups.quantile(q=0.00)
		qmax = groups.quantile(q=1.00)
		upper = [min([x,y]) for (x,y) in zip(list(qmax.loc[:,'premium']),__upper.premium)]
		lower = [max([x,y]) for (x,y) in zip(list(qmin.loc[:,'premium']),__lower.premium)]

		# find the outliers for each category
		def outliers(group):
			cat = group.name
			return group[(group.premium > __upper.loc[cat]['premium']) | (group.premium < __lower.loc[cat]['premium'])]['premium']
		out = groups.apply(outliers).dropna()

		# prepare outlier data i.e. get outlier co-ordinates for plotting
		if not out.empty:
			outx = []
			outy = []
			for keys in out.index:
				outx.append(keys[0])
				outy.append(out.loc[keys[0]].loc[keys[1]])

		# Create ColumnDataSource for quartiles and IQR data for data binding
		source = ColumnDataSource(data=dict(cats=cats, q1=q1.premium, q2=q2.premium, 
											q3=q3.premium, upper=upper, lower=lower))
		# Create ColumnDataSource for outlier data for data binding
		outlier_source = ColumnDataSource(data=dict(outx=outx, outy=outy, out=out))

		return source, outlier_source

	# Function for general plot styling
	def style(p):
		# Title 
		p.title.align = 'center'
		p.title.text_font_size = '15pt'
		p.title.text_font = 'serif'

		# Axis titles
		p.xaxis.axis_label_text_font_size = '12pt'
		p.xaxis.axis_label_text_font_style = 'normal'
		p.yaxis.axis_label_text_font_size = '12pt'
		p.yaxis.axis_label_text_font_style = 'normal'

		# Tick labels
		p.xaxis.major_label_text_font_size = '10pt'
		p.yaxis.major_label_text_font_size = '10pt'

		return p

	# Function to create histogram plot 
	def make_hist(src):
		# Blank plot with correct labels
		p = figure(plot_width = 600, plot_height = 600, 
				  title = 'Histogram of COE Prices by Category',
				  x_axis_label = 'COE Prices', y_axis_label = 'Proportion')
		
		p.xaxis.formatter = BasicTickFormatter(use_scientific=False)
		p.yaxis.formatter = BasicTickFormatter(use_scientific=False)

		# Quad glyphs to create a histogram
		p.quad(source = src, bottom = 0, top = 'proportion', left = 'left', right = 'right',
			   color = 'color', fill_alpha = 0.7, hover_fill_color = 'color', legend = 'name',
			   hover_fill_alpha = 1.0, line_color = 'black', fill_color="#E08E79")

		# Hover tool with vline mode
		hover = HoverTool(tooltips=[('Category', '@name'), 
									('COE Price', '@f_interval'),
									('Proportion', '@f_proportion')],
						  mode='vline')

		p.add_tools(hover)

		# Styling
		p = style(p)

		return p

	# Function to create boxplot
	def make_boxplot(src, outlier_src):	

		cats = src.data['cats']
		p = figure(x_range=FactorRange(*cats), tools="", 
				   title = 'Boxplot of COE yearly prices by Category',
				   plot_width = 600, plot_height = 600, toolbar_location=None)

		p.yaxis.formatter = BasicTickFormatter(use_scientific=False)
		p.yaxis.formatter = BasicTickFormatter(use_scientific=False)
		
		# stems
		p.segment(x0='cats', y0='upper', x1='cats', y1='q3', line_color="black", source=src)
		p.segment(x0='cats', y0='lower', x1='cats', y1='q1', line_color="black", source=src)

		# boxes
		p.vbar(x='cats', width=0.7, bottom='q2', top='q3', fill_color="#E08E79", line_color="black", source=src)
		p.vbar(x='cats', width=0.7, bottom='q1', top='q2', fill_color="#3B8686", line_color="black", source=src)

		# whiskers (almost-0 height rects simpler than segments)
		p.rect(x='cats', y='lower', width=0.2, height=0.01, line_color="black", source=src)
		p.rect(x='cats', y='upper', width=0.2, height=0.01, line_color="black", source=src)

		# outliers
		out = outlier_src.data['out']
		if not out.empty:
			p.circle(x='outx', y='outy', size=6, color="#F38630", fill_alpha=0.6, source=outlier_src)

		p.xgrid.grid_line_color = None
		p.ygrid.grid_line_color = "white"
		p.grid.grid_line_width = 2
		p.xaxis.major_label_text_font_size="12pt"

		# Styling
		p = style(p)

		return p	

	# Function for data update based on user parameter selection
	def update(attr, old, new):
    	# Origin and destination determine values displayed
		category = category_select.value
		
		new_src1 = make_dataset(category,
							   year_start = period_select.value[0],
							   year_end = period_select.value[1])	
		
		new_src2, new_outlier_src = make_bpdata(category,
							   year_start = period_select.value[0],
							   year_end = period_select.value[1])

		p2.x_range.factors = []
		p2.x_range.factors = new_src2.data['cats']

		src1.data.update(new_src1.data)
		src2.data.update(new_src2.data)
		outlier_src.data.update(new_outlier_src.data)

	# Get saved user settings from database if available, otherwise define default parameter values 
	# if database offline or no saved user setttings found
	try:
		client = MongoClient(serverSelectionTimeoutMS=500) # connect to the local mongoDB server
		db = client.mydb # set active database to mydb

		collection = db.histogran_boxplot_settings
		df = pd.DataFrame(list(collection.find())) # retrieve all data from COE as a df
		if not df.empty:
			category_setting = df['category'].values[0]
			year_start_setting = int(df['year_start'].values[0])
			year_end_setting = int(df['year_end'].values[0])
		else:
			category_setting = "Category A"
			year_start_setting = 2010
			year_end_setting = 2019  

	except pymongo.errors.ServerSelectionTimeoutError as err:
		category_setting = "Category A"
		year_start_setting = 2010
		year_end_setting = 2019  				

	# Compute categorical information for parameter selection
	# Vehicle Classes e.g. Cat A, Cat B etc.
	vehicle_classes = list(set(coe_prices_df['vehicle_class']))
	vehicle_classes.sort()

	# Create select widget for vehicle class selection
	category_select = Select(title = 'Vehicle Class', value = category_setting, options = vehicle_classes)
	category_select.on_change('value', update)

	# Create range slider widget for start/end year selection
	period_select = RangeSlider(start = 2010, end = 2019, value = (year_start_setting, year_end_setting),
							   step = 1, title = 'Year')
	period_select.on_change('value', update)

	# Compute dataset for histogram plot
	src1 = make_dataset(category_select.value,
					   year_start = period_select.value[0],
					   year_end = period_select.value[1])

	# Compute dataset for boxplot
	src2, outlier_src = make_bpdata(category_select.value,
					   year_start = period_select.value[0],
					   year_end = period_select.value[1])
					   
	# Create histogram plot based on computed dataset 				   
	p1 = make_hist(src1)

	# Create boxplot based on computed dataset
	p2 = make_boxplot(src2, outlier_src)

	# Create button widgets for saving setting/results
	btn_settings = Button(label='Save Settings')
	btn_results = Button(label='Save Results')

	# Click event handler for "Save Settings" button
	def save_settings():
		try:
			category = category_select.value
			year_start = period_select.value[0]
			year_end = period_select.value[1]

			collection = db.histogran_boxplot_settings # set collection active
			collection.delete_many({})
			collection.insert_one({"category" : category, "year_start" : year_start, "year_end" : year_end})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Click event handler for "Save Results" button
	def save_results():
		try:
			left = src1.data['left']
			right = src1.data['right']
			proportion = src1.data['f_proportion']

			collection = db.histogran_boxplot_results # set collection active

			for i in range(len(left)):
				collection.insert_one({"From" : left[i], "To" : right[i], "Proportion" : proportion[i]})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")			

	# Connect "Save Settings" button widget with "save_settings" click event handler
	btn_settings.on_click(save_settings)
	# Connect "Save Results" button widget with "save_results" click event handler
	btn_results.on_click(save_results)

	# Put controls in a single element
	controls = WidgetBox(category_select, period_select, btn_settings, btn_results)
	
	# Create a row layout
	layout = row(controls, p1, p2)
	
	# Make a tab with the layout 
	tab = Panel(child=layout, title = 'Histogram_Boxplot')

	return tab
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# pandas and numpy for data manipulation
import pandas as pd
import numpy as np
from math import pi

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool, 
						  ColumnDataSource, Panel, FactorRange,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider, 
								  Tabs, CheckboxButtonGroup, 
								  TableColumn, DataTable, Select, Button)
from bokeh.layouts import column, row, WidgetBox
from bokeh.palettes import Spectral5, Category20c, Spectral6
from bokeh.transform import factor_cmap, cumsum

import pymongo
from pymongo import MongoClient

# Make plot with pie chart and return tab
def piechart_tab(car_reg_by_fuelType_df):

	# Function to make a dataset for pie chart based on selected category, start year and end year
	def make_dataset(category, year_start = 2016, year_end = 2019):

		# Get fuel type values as list
		types = car_reg_by_fuelType_df['type'].unique().tolist()
		# Assign color scheme for fuel types
		type_colors = dict(zip(types, Category20c[len(types)]))

		# Filter for specific vehicle category and period range
		cat_condition = car_reg_by_fuelType_df['category'] == category
		year_condition = (car_reg_by_fuelType_df['year'] >= year_start) & (car_reg_by_fuelType_df['mth'] <= year_end)
		subset = car_reg_by_fuelType_df[cat_condition & year_condition]

		# Group filtered dataset by Fuel Type and compute aggregated count
		subset_group = pd.DataFrame({'sum' : subset.groupby('type')['number'].sum()}).reset_index()
		subset_group['angle'] = subset_group['sum']/subset_group['sum'].sum() * 2*pi

		# Compute color based on fuel type color scheme
		def getColor(group):
			return type_colors[group['type']]
		subset_group['color'] = subset_group.apply(lambda group: getColor(group), axis=1)

		# Compute percentage value for each fuel type
		subset_group['percent'] = subset_group['sum'] / subset_group['sum'].sum() * 100

		# Create ColumnDataSource from fuel type data for data binding
		source = ColumnDataSource(subset_group)

		return source

	# Function for general plot styling
	def style(p):
		# Title 
		p.title.align = 'center'
		p.title.text_font_size = '15pt'
		p.title.text_font = 'serif'

		# Axis titles
		p.xaxis.axis_label_text_font_size = '8pt'
		p.xaxis.axis_label_text_font_style = 'normal'
		p.yaxis.axis_label_text_font_size = '10pt'
		p.yaxis.axis_label_text_font_style = 'normal'

		# Tick labels
		p.xaxis.major_label_text_font_size = '8pt'
		p.yaxis.major_label_text_font_size = '10pt'

		return p

	# Function to create pie chart plot
	def make_plot(src):
		p = figure(plot_height=500, title="Car Type Distribution", toolbar_location=None,
				tools="hover", tooltips="@type: @percent{0.2f} %", x_range=(-0.5, 1.0))

		p.wedge(x=0, y=1, radius=0.4,
				start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
				line_color="white", fill_color='color', legend='type', source=src)

		p.axis.axis_label=None
		p.axis.visible=False
		p.grid.grid_line_color = None

		# Styling
		p = style(p)

		return p
	
	# Function for data update based on user parameter selection
	def update(attr, old, new):
		new_src = make_dataset(category_select.value,
							   year_start = period_select.value[0],
							   year_end = period_select.value[1])		

		src.data.update(new_src.data)

	# Get saved user settings from database if available, otherwise define default parameter values 
	# if database offline or no saved user setttings found		
	try:
		client = MongoClient(serverSelectionTimeoutMS=500) # connect to the local mongoDB server
		db = client.mydb # set active database to mydb

		collection = db.piechart_settings
		df = pd.DataFrame(list(collection.find())) # retrieve all data from COE as a df
		if not df.empty:
			category_setting = df['category'].values[0]
			year_start_setting = int(df['year_start'].values[0])
			year_end_setting = int(df['year_end'].values[0])
		else:
			category_setting = "Cars"
			year_start_setting = 2016 		
			year_end_setting = 2019 

	except pymongo.errors.ServerSelectionTimeoutError as err:
		category_setting = "Cars"
		year_start_setting = 2016 		
		year_end_setting = 2019   	

	# Compute categorical information for parameter selection
	# Vehicle Make e.g. FIAT, HONDA etc.
	categories = list(set(car_reg_by_fuelType_df['category']))
	categories.sort()	

	# Create select widget for vehicle category selection	
	category_select = Select(title = 'Category', value = category_setting, options = categories)
	category_select.on_change('value', update)

	# Create range slider widget for start/end year selection
	period_select = RangeSlider(start = 2016, end = 2019, value = (year_start_setting, year_end_setting),
							   step = 1, title = 'Year')
	period_select.on_change('value', update)

	# Compute dataset for piechart plot	
	src = make_dataset(category_select.value, year_start = period_select.value[0], year_end = period_select.value[1])

	# Create piechart plot based on computed dataset 
	p = make_plot(src)

	# Create button widgets for saving setting/results
	btn_settings = Button(label='Save Settings')
	btn_results = Button(label='Save Results')

	# Click event handler for "Save Settings" button
	def save_settings():
		try:
			category = category_select.value
			year_start = period_select.value[0]
			year_end = period_select.value[1]

			collection = db.piechart_settings # set collection active
			collection.delete_many({})
			collection.insert_one({"category" : category, "year_start" : year_start, "year_end" : year_end})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Click event handler for "Save Results" button
	def save_results():
		try:
			subset_group = src.data

			collection = db.piechart_results # set collection active

			for i in range(len(subset_group["type"])):
				_type = str(subset_group["type"][i])
				_sum = float(subset_group["sum"][i])
				_angle = int(subset_group["angle"][i])
				_color = str(subset_group["color"][i])
				_percent = float(subset_group["percent"][i])
				collection.insert_one({"Type" : _type, "Sum" : _sum, "Angle" : _angle, "Color" : _color, "Percent" : _percent})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Connect "Save Settings" button widget with "save_settings" click event handler
	btn_settings.on_click(save_settings)
	# Connect "Save Results" button widget with "save_results" click event handler
	btn_results.on_click(save_results)

	# Put controls in a single element
	controls = WidgetBox(category_select, period_select, btn_settings, btn_results)
	
	# Create a row layout
	layout = row(controls, p)
	
	# Make a tab with the layout 
	tab = Panel(child=layout, title = 'Pie Chart')

	return tab
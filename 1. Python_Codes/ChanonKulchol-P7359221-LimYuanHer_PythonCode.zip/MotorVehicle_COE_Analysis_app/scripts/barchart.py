import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# pandas and numpy for data manipulation
import pandas as pd
import numpy as np
import math

from bokeh.plotting import figure, reset_output
from bokeh.models import (CategoricalColorMapper, HoverTool, 
						  ColumnDataSource, Panel, FactorRange,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider, 
								  Tabs, CheckboxButtonGroup, 
								  TableColumn, DataTable, Select, Button)
from bokeh.layouts import column, row, WidgetBox
from bokeh.palettes import Spectral5
from bokeh.transform import factor_cmap

import pymongo
from pymongo import MongoClient

# Make plot with bar chart and return tab
def barchart_tab(car_reg_by_make_df):

	# Function to make a dataset for bar chart based on selected vehicle type,
	# top K items, start year and end year
	def make_dataset(vehicletype, topK, year_start = 2016, year_end = 2019):

		# Filter for specific vehicle type and period range
		type_condition = car_reg_by_make_df['vehicle_type'] == vehicletype
		year_condition = (car_reg_by_make_df['year'] >= year_start) & (car_reg_by_make_df['year'] <= year_end)
		subset = car_reg_by_make_df[type_condition & year_condition]

		# Group filtered dataset by Fuel Type and Vehicle Make and compute aggregated count
		subset_group = pd.DataFrame({'sum' : subset.groupby(by=['fuel_type', 'make'])['number'].sum()}).reset_index()

		# Get top K results for each Fuel Type
		subset_topK = pd.DataFrame({'sum' : subset_group.groupby('fuel_type')['sum'].nlargest(int(topK))}).reset_index()
		subset_topK.rename(columns={'level_1': 'make'}, inplace=True)
		# Get Vehicle Make information for each result
		subset_topK['make'] = subset_topK.apply (lambda row: subset_group.iloc[int(row['make'])]['make'], axis=1)

		# Convert top K results dataframe to tuple
		subset_tuple = subset_topK.apply(tuple, axis=1)

		# Split top K tuples into "x" and "total" tuples for input data to bar chart visualization 
		x = [(fueltype, make) for (fueltype, make, total) in subset_tuple]
		total = [total for (fueltype, make, total) in subset_tuple]

		# Create ColumnDataSource from top K tuples for data binding
		source = ColumnDataSource(data=dict(x=x, total=total))

		return source
	
	# Function for general plot styling
	def style(p):
		# Title 
		p.title.align = 'center'
		p.title.text_font_size = '15pt'
		p.title.text_font = 'serif'

		# Axis titles
		p.xaxis.axis_label_text_font_size = '10pt'
		p.xaxis.axis_label_text_font_style = 'normal'
		p.yaxis.axis_label_text_font_size = '10pt'
		p.yaxis.axis_label_text_font_style = 'normal'

		# Tick labels
		p.xaxis.major_label_text_font_size = '10pt'
		p.yaxis.major_label_text_font_size = '10pt'

		return p

	# Function to create bar chart plot
	def make_plot(src):
		x = src.data['x']
		p = figure(x_range=FactorRange(*x), plot_height=500, plot_width=1000, title="Car registrations by Fuel Type and Make",
				toolbar_location=None, tools="")

		p.vbar(x='x', top='total', width=0.9, source=src)

		p.y_range.start = 0
		p.x_range.range_padding = 0.1
		p.xaxis.major_label_orientation = math.pi/2
		p.xgrid.grid_line_color = None

		# Styling
		p = style(p)

		return p

	# Function for data update based on user parameter selection
	def update(attr, old, new):
		#reset_output()
		new_src = make_dataset(vehicletype_select.value, topK_select.value,
							   year_start = period_select.value[0],
							   year_end = period_select.value[1])		

		p.x_range.factors = new_src.data['x']
		src.data.update(new_src.data)

	# Get saved user settings from database if available, otherwise define default parameter values 
	# if database offline or no saved user setttings found
	try:
		client = MongoClient(serverSelectionTimeoutMS=500) # connect to the local mongoDB server
		db = client.mydb # set active database to mydb

		collection = db.barchart_settings
		df = pd.DataFrame(list(collection.find())) # retrieve all data from COE as a df
		if not df.empty:
			vehicletype_setting = df['vehicletype'].values[0]
			topK_setting = str(df['topK'].values[0])
			year_start_setting = int(df['year_start'].values[0])
			year_end_setting = int(df['year_end'].values[0])
		else:
			vehicletype_setting = "Sedan"
			topK_setting = '5'
			year_start_setting = 2016 		
			year_end_setting = 2019  

	except pymongo.errors.ServerSelectionTimeoutError as err:
		vehicletype_setting = "Sedan"
		topK_setting = '5'
		year_start_setting = 2016 		
		year_end_setting = 2019  	

	# Compute categorical information for parameter selection
	# Vehicle Make e.g. FIAT, HONDA etc.
	makes = list(set(car_reg_by_make_df['make']))
	makes.sort()

	# Fuel Type e.g. Petrol, Diesel etc.
	fuel_types = list(set(car_reg_by_make_df['fuel_type']))
	fuel_types.sort()	

	# Vehicle Types e.g. HatchBack, Sedan etc.
	vehicle_types = list(set(car_reg_by_make_df['vehicle_type']))
	vehicle_types.sort()	

	topK = ['5','8','10']		

	# Create select widget for vehicle type selection	
	vehicletype_select = Select(title = 'Vehicle Type', value = vehicletype_setting, options = vehicle_types)
	vehicletype_select.on_change('value', update)

	# Create select widget for top K selection	
	topK_select = Select(title = 'TopK', value = topK_setting, options = topK)
	topK_select.on_change('value', update)

	# Create range slider widget for start/end year selection
	period_select = RangeSlider(start = 2016, end = 2019, value = (year_start_setting, year_end_setting),
							   step = 1, title = 'Year')
	period_select.on_change('value', update)

	# Compute dataset for barchart plot
	src = make_dataset(vehicletype_select.value, topK_select.value,
					   year_start = period_select.value[0], year_end = period_select.value[1])

	# Create barchart plot based on computed dataset 
	p = make_plot(src)

	# Create button widgets for saving setting/results
	btn_settings = Button(label='Save Settings')
	btn_results = Button(label='Save Results')

	# Click event handler for "Save Settings" button
	def save_settings():
		try:
			vehicletype = vehicletype_select.value
			topK = topK_select.value
			year_start = period_select.value[0]
			year_end = period_select.value[1]

			collection = db.barchart_settings # set collection active
			collection.delete_many({})
			collection.insert_one({"vehicletype" : vehicletype, "topK" : topK, "year_start" : year_start, "year_end" : year_end})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Click event handler for "Save Results" button
	def save_results():
		try:
			x = src.data['x']
			total = src.data['total']

			collection = db.barchart_results # set collection active

			for i in range(len(x)):
				collection.insert_one({"x" : x[i], "total" : total[i]})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Connect "Save Settings" button widget with "save_settings" click event handler
	btn_settings.on_click(save_settings)
	# Connect "Save Results" button widget with "save_results" click event handler
	btn_results.on_click(save_results)

	# Put controls in a single element
	controls = WidgetBox(vehicletype_select, topK_select, period_select, btn_settings, btn_results)
	
	# Create a row layout
	layout = row(controls, p)
	
	# Make a tab with the layout 
	tab = Panel(child=layout, title = 'Bar Chart')

	return tab
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=RuntimeWarning)

from pandas.core.common import SettingWithCopyWarning
warnings.simplefilter(action='ignore', category=SettingWithCopyWarning)

# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from datetime import date
from random import randint

from bokeh.plotting import figure, curdoc, reset_output
from bokeh.models import (CategoricalColorMapper, HoverTool, 
						  ColumnDataSource, Panel, FactorRange, BasicTickFormatter,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider, 
								  Tabs, CheckboxButtonGroup, Div, Button,
								  TableColumn, DataTable, Select, DateFormatter)

from bokeh.layouts import column, row, WidgetBox
from bokeh.palettes import Spectral5
from bokeh.transform import factor_cmap

import pymongo
from pymongo import MongoClient

# Make plot with scatter plot and return tab
def scatterplot_tab(car_reg_by_make_df, coe_prices_df):

	# Function to make a dataset for scatter plot based on selected vehicle make, 
	# vehicle type and class
	def make_dataset(make, vehicletype, vehicleclass):
		try:
			# Filter for specific vehicle make, type and class
			vehicletype_condition = car_reg_by_make_df['vehicle_type'] == vehicletype
			make_condition = car_reg_by_make_df['make'] == make
			car_reg_by_make_filtered = car_reg_by_make_df[make_condition & vehicletype_condition]

			# Group filtered dataset by year-month and vehicle class and compute arithmetic mean of COE premium
			coe_prices_df_grouped = pd.DataFrame({'mean' : coe_prices_df.groupby(['month','vehicle_class'])['premium'].mean()}).reset_index()
			coe_prices_df_filtered = coe_prices_df_grouped[coe_prices_df_grouped['vehicle_class'] == vehicleclass]

			# Merge filtered grouped dataset with COE price dataset 
			car_reg_by_make_with_COE = car_reg_by_make_filtered.merge(coe_prices_df_filtered, left_on='month', right_on='month').dropna()
			car_reg_by_make_with_COE_filtered = car_reg_by_make_with_COE[car_reg_by_make_with_COE['number'] != 0]

			# Calculate linear regression line for scatter plot
			x=np.array(car_reg_by_make_with_COE_filtered['number'].tolist())
			y=np.array(car_reg_by_make_with_COE_filtered['mean'].tolist())

			# determine best fit line		
			par = np.polyfit(x, y, 1, full=True)
			slope=par[0][0]
			intercept=par[0][1]
			car_reg_by_make_with_COE_filtered.loc[:, 'LR_Data'] = [slope*i + intercept  for i in x]

			# Create ColumnDataSource from dataset for data binding
			source = ColumnDataSource(car_reg_by_make_with_COE_filtered)
		except Exception:
			source = None

		return source

	# Function to make a dataset for data correlation results based on selected vehicle make, 
	# vehicle type and class
	def make_corr(make, vehicleclass, vehicletype):
		try:
			# Compute top 5 most postiive/negative correlations
			df_pos_corr, df_neg_corr = getTopKByFactor(make, vehicleclass, vehicletype)

			# Create dictionary and associated ColumnDataSource from df_pos_corr data for data binding
			data = dict(
				Category=df_pos_corr['Category'].tolist(),
				Make=df_pos_corr['Make'].tolist(),
				Type=df_pos_corr['Type'].tolist(),
				Corr_Coef=df_pos_corr['Corr_Coef'].tolist()
			)
			source = ColumnDataSource(data)

			# Create dictionary and associated ColumnDataSource from df_neg_corr data for data binding
			data2 = dict(
				Category=df_neg_corr['Category'].tolist(),
				Make=df_neg_corr['Make'].tolist(),
				Type=df_neg_corr['Type'].tolist(),
				Corr_Coef=df_neg_corr['Corr_Coef'].tolist()
			)
			source2 = ColumnDataSource(data2)
		except Exception:
			source = None

		return source, source2

	# Function to compute top 5 most positive/negative data correlations based on  
	# selected vehicle make, vehicle type and class		
	def getTopKByFactor(make="", vehicleclass="", vehicletype=""):
		
		# Create empty dataframe for data correlation results
		col_names =  ['Category', 'Make', 'Type', 'Corr_Coef', 'Data']
		df_corr  = pd.DataFrame(columns = col_names)
	
		# Assign vehicle make list for data correlation analysis based on function input
		if(make != ""):
			makes_list = [make]
		else:
			makes_list = makes

		# Assign vehicle class list for data correlation analysis based on function input	
		if(vehicleclass != ""):
			vehicle_classes_list = [vehicleclass]    
		else:
			vehicle_classes_list = vehicle_classes
			
		# Assign vehicle type list for data correlation analysis based on function input
		if(vehicletype != ""):
			vehicle_types_list = [vehicletype]  
		else:
			vehicle_types_list = vehicle_types
	
		# Group COE price dataset by Vehicle Class and compute arithmetic mean
		df_coe_group = pd.DataFrame({'mean' : coe_prices_df.groupby(['month','vehicle_class'])['premium'].mean()}).reset_index()

		# Compute correlation coefficient for each vehicle class, make and type combination
		for k in range(len(vehicle_classes_list)):
    		# Filter COE grouped price dataset for vehicle class
			coe_df = df_coe_group[df_coe_group['vehicle_class'] == vehicle_classes_list[k]]
			# Loop through all combination of vehicle makes and types
			for i in range(len(makes_list)):
				for j in range(len(vehicle_types_list)):
    				# Filter car registration by make dataset for vehicle make and type
					df = car_reg_by_make_df[(car_reg_by_make_df['make'] == makes_list[i]) & (car_reg_by_make_df['vehicle_type'] == vehicle_types_list[j])]
					# Merge filtered dataset with COE filtered grouped dataset
					df2 = df.merge(coe_df, left_on='month', right_on='month').dropna()
					# Filter out data records with zero cars registered
					df2 = df2[df2['number'] != 0]
					# Compute data correlation between number of cars registered and COE average premium
					df2 = df2[['number','mean']]
					# Append computed data correlation to data correlation dataframe
					df_corr.loc[len(df_corr)] = {
													'Category':vehicle_classes_list[k], 
													'Make':makes_list[i], 
													'Type':vehicle_types_list[j], 
													'Corr_Coef':round(df2['number'].corr(df2['mean'], min_periods=36), 3),
													'Data':df2
												}
	
		# Remove data records with null correlation coefficient results
		df_corr = df_corr.dropna()
	
		# Sort data correlation dataframe by coefficient in descending order and get first 5 records for top 5 most positive correlation
		top5PosCorr =  df_corr.sort_values(by='Corr_Coef', ascending=False).head(5)
		# Sort data correlation dataframe by coefficient in ascending order and get first 5 records for top 5 most negative correlation
		top5NegCorr =  df_corr.sort_values(by='Corr_Coef', ascending=True).head(5)
		return top5PosCorr, top5NegCorr

	# Function for general plot styling
	def style(p):
		# Title 
		p.title.align = 'center'
		p.title.text_font_size = '15pt'
		p.title.text_font = 'serif'

		# Axis titles
		p.xaxis.axis_label_text_font_size = '8pt'
		p.xaxis.axis_label_text_font_style = 'normal'
		p.yaxis.axis_label_text_font_size = '10pt'
		p.yaxis.axis_label_text_font_style = 'normal'

		# Tick labels
		p.xaxis.major_label_text_font_size = '8pt'
		p.yaxis.major_label_text_font_size = '10pt'

		return p

	# Function to create scatter plot
	def make_plot(src):
		# Blank plot with correct labels
		p = figure(plot_width = 700, plot_height = 500, 
				  title = 'Scatter Plot of car model registration with COE Prices',
				  x_axis_label = 'Car Make Qty', y_axis_label = 'COE Prices')

		p.yaxis.formatter = BasicTickFormatter(use_scientific=False)
		p.yaxis.formatter = BasicTickFormatter(use_scientific=False)

		p.scatter(
			'number', 
			'mean', source=src)

		p.line(x='number', y='LR_Data', line_width=2, source=src)

		# Styling
		p = style(p)

		return p

	# Function to create data table for displaying top K correlation results
	def make_table(src, src2):
		columns = [
			TableColumn(field="Category", title="Category"),
			TableColumn(field="Make", title="Make"),
			TableColumn(field="Type", title="Type"),
			TableColumn(field="Corr_Coef", title="Corr_Coef")
		]

		data_table = DataTable(source=src, columns=columns, width=500, height=200)
		data_table2 = DataTable(source=src2, columns=columns, width=500, height=200)

		return data_table, data_table2

	# Function for data update based on user parameter selection
	def update(attr, old, new):
		new_src = make_dataset(make_select.value, vehicletype_select.value, vehicleclass_select.value)		

		new_source, new_source2 = make_corr(make=make_select.value, vehicleclass=vehicleclass_select.value, vehicletype=vehicletype_select.value)		
		source.data.update(new_source.data)
		source2.data.update(new_source2.data)

		if(new_src != None):
			src.data.update(new_src.data)

	# Get saved user settings from database if available, otherwise define default parameter values 
	# if database offline or no saved user setttings found			
	try:
		client = MongoClient(serverSelectionTimeoutMS=500) # connect to the local mongoDB server
		db = client.mydb # set active database to mydb

		collection = db.scatterplot_settings
		df = pd.DataFrame(list(collection.find())) # retrieve all data from COE as a df
		if not df.empty:
			make_setting = df['make'].values[0]
			vehicletype_setting = df['vehicletype'].values[0]
			vehicleclass_setting = df['vehicleclass'].values[0]
		else:
			make_setting = "TOYOTA"
			vehicletype_setting = 'Sedan' 		
			vehicleclass_setting = 'Category A' 

	except pymongo.errors.ServerSelectionTimeoutError as err:
		make_setting = "TOYOTA"
		vehicletype_setting = 'Sedan' 		
		vehicleclass_setting = 'Category A' 

	# Compute categorical information for parameter selection		
	# Vehicle Make e.g. FIAT, HONDA etc.
	makes = [""] + list(set(car_reg_by_make_df['make']))
	makes.sort()

	# Fuel Type e.g. Petrol, Diesel etc.
	fuel_types = [""] + list(set(car_reg_by_make_df['fuel_type']))
	fuel_types.sort()	

	# Vehicle Types e.g. HatchBack, Sedan etc.
	vehicle_types = [""] + list(set(car_reg_by_make_df['vehicle_type']))
	vehicle_types.sort()	

	# Vehicle Classes e.g. Category A, Category B etc.
	vehicle_classes = [""] + list(set(coe_prices_df['vehicle_class']))
	vehicle_classes.sort()	

	# Create select widget for vehicle make selection
	make_select = Select(title = 'Make', value = make_setting, options = makes)
	make_select.on_change('value', update)

	# Create select widget for vehicle type selection
	vehicletype_select = Select(title = 'Vehicle Type', value = vehicletype_setting, options = vehicle_types)
	vehicletype_select.on_change('value', update)

	# Create select widget for vehicle class selection
	vehicleclass_select = Select(title = 'Vehicle Class', value = vehicleclass_setting, options = vehicle_classes)
	vehicleclass_select.on_change('value', update)

	# Compute dataset for scatter plot	
	src = make_dataset(make_select.value, vehicletype_select.value, vehicleclass_select.value)

	# Create scatter plot based on computed dataset 
	p = make_plot(src)

	# Compute dataset for data table		
	source, source2 = make_corr(make=make_select.value, vehicleclass=vehicleclass_select.value, vehicletype=vehicletype_select.value)

	# Create data table plot based on computed dataset 
	data_table, data_table2 = make_table(source, source2)

	# Create button widgets for saving setting/results	
	btn_settings = Button(label='Save Settings')
	btn_results = Button(label='Save Results')

	# Click event handler for "Save Settings" button
	def save_settings():
		try:
			make = make_select.value
			vehicletype = vehicletype_select.value
			vehicleclass = vehicleclass_select.value

			collection = db.scatterplot_settings # set weights collection active
			collection.delete_many({})
			collection.insert_one({"make" : make, "vehicletype" : vehicletype, "vehicleclass" : vehicleclass})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Click event handler for "Save Results" button
	def save_results():
		try:
			for src in [source, source2]:
				_cat = src.data['Category']
				_make = src.data['Make']
				_type = src.data['Type']
				_corrcoef = src.data['Corr_Coef']			

				collection = db.scatterplot_results # set collection active

				for i in range(len(_cat)):
					collection.insert_one({"Category" : _cat[i], "Make" : _make[i], "Type" : _type[i], "Corr_Coef" : _corrcoef[i]})
		except pymongo.errors.ServerSelectionTimeoutError as err:
			print("No connection to database")

	# Connect "Save Settings" button widget with "save_settings" click event handler
	btn_settings.on_click(save_settings)
	# Connect "Save Results" button widget with "save_results" click event handler
	btn_results.on_click(save_results)

	# Function for setting select widget values based on data_table row selection
	def update_source(attr, old, new):
		try:
			selected_index = source.selected.indices[0]
			vehicleclass_select.value = str(source.data["Category"][selected_index])
			make_select.value = str(source.data["Make"][selected_index])
			vehicletype_select.value = str(source.data["Type"][selected_index])
		except IndexError:
			pass

	# Function for setting select widget values based on data_table2 row selection
	def update_source2(attr, old, new):
		try:
			selected_index = source2.selected.indices[0]
			vehicleclass_select.value = str(source2.data["Category"][selected_index])
			make_select.value = str(source2.data["Make"][selected_index])
			vehicletype_select.value = str(source2.data["Type"][selected_index])
		except IndexError:
			pass

	# Connect data_table row select event to "update_source" event handler
	source.selected.on_change('indices', update_source)
	# Connect data_table2 row select event to "update_source2" event handler
	source2.selected.on_change('indices', update_source2)

	# Put controls in a single element
	controls = WidgetBox(make_select, vehicletype_select, vehicleclass_select, btn_settings, btn_results)

	# Set title for data_table
	html = """<span><h3>Top 5 positive correlations</h3></span>"""
	sup_title = Div(text=html)

	# Set title for data_table2
	html2 = """<span><h3>Top 5 negative correlations</h3></span>"""
	sup_title2 = Div(text=html2)

	# Create a row layout
	layout = row(controls, p, column(sup_title, data_table, sup_title2, data_table2))
	
	# Make a tab with the layout 
	tab = Panel(child=layout, title = 'Scatter Plot')

	return tab
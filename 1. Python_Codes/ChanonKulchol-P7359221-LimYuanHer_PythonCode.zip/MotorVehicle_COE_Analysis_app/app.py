# Pandas for data management
import pandas as pd

# os methods for manipulating paths
from os.path import dirname, join

# Bokeh basics 
from bokeh.io import curdoc
from bokeh.models.widgets import Tabs, Div
from bokeh.layouts import column
from bokeh.server.server import Server

# import tab scripts
from scripts.histogram_boxplot import histogram_boxplot_tab
from scripts.barchart import barchart_tab
from scripts.piechart import piechart_tab
from scripts.scatterplot import scatterplot_tab

# Function for getting year, month data from year-month data column
def split_date(row, period):
    if(period == 'year'):
        return int(row['month'].split('-')[0])
    elif(period == 'month'):
        return int(row['month'].split('-')[1])

# Function for creating year, month data columns from year-month data column      
def create_YearMthCols(df):
    df['year'] = df.apply (lambda row: split_date(row, 'year'), axis=1)
    df['mth'] = df.apply (lambda row: split_date(row, 'month'), axis=1)

    return df

# Function for application initialization
def start(doc):
    # Read COE data into dataframe
    coe_prices_df = pd.read_csv(join(dirname(__file__), 'data', 'coe-results.csv'), header=0).dropna()
    coe_prices_df = create_YearMthCols(coe_prices_df)

    # Read vehicles by fuel type into dataframe
    car_reg_by_fuelType_df = pd.read_csv(join(dirname(__file__), 'data', 'M09-Vehs_by_Fuel_Type.csv'), header=0)
    car_reg_by_fuelType_df = create_YearMthCols(car_reg_by_fuelType_df)

    # Read vehicles by type into dataframe
    car_reg_by_type_df = pd.read_csv(join(dirname(__file__), 'data', 'M06-Vehs_by_Type.csv'), header=0)
    car_reg_by_type_df = create_YearMthCols(car_reg_by_type_df)

    # Read Registered cars by make/model into dataframe
    car_reg_by_make_df = pd.read_csv(join(dirname(__file__), 'data', 'M03-Car_Regn_by_make.csv'), header=0)
    car_reg_by_make_df = create_YearMthCols(car_reg_by_make_df)

    # Add a title for the entire visualization using Div
    html = """<span><h2>Motor Vehicle COE Analysis</h2></span>"""
    sup_title = Div(text=html)

    # Create each of the tabs
    tab1 = histogram_boxplot_tab(coe_prices_df)
    tab2 = barchart_tab(car_reg_by_make_df)
    tab3 = piechart_tab(car_reg_by_fuelType_df)
    tab4 = scatterplot_tab(car_reg_by_make_df, coe_prices_df)

    # Put all the tabs into one application
    tabs = Tabs(tabs = [tab1, tab2, tab3, tab4])

    # Put the tabs in the current document for display
    doc.add_root(column(sup_title, tabs))
    doc.title = "Motor Vehicle COE Analysis"

# Initializa and start Bokeh server at port 5006
server = Server({'/': start}, num_procs=1)
server.start()

if __name__ == '__main__':
    print('Starting Motor Vehicle COE Analysis application on http://localhost:5006/')

    server.io_loop.add_callback(server.show, "/")
    server.io_loop.start()

